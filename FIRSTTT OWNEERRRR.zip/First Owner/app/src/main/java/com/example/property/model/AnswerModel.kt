package com.example.property.model

data class AnswerModel(var id:Int,var title:String,var i_date:String,var a_date:String,var inquiry_msg:String,var inquiry_ans:String)