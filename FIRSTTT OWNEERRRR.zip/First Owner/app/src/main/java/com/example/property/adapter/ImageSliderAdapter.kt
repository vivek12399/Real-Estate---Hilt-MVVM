package com.example.property.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.property.databinding.ImageSliderListBinding
import com.example.property.databinding.PopupSliderLayoutBinding
import com.example.property.model.ImageItem

class ImageSliderAdapter(private val imageList: List<ImageItem>) :
    RecyclerView.Adapter<ImageSliderAdapter.ImageSliderViewHolder>() {

    inner class ImageSliderViewHolder(val binding: ImageSliderListBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageSliderViewHolder {
        val binding = ImageSliderListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageSliderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageSliderViewHolder, position: Int) {
        val imageView = holder.binding.sliderImageView
        imageView.setImageResource(imageList[position].imageResId)
    }

    override fun getItemCount(): Int {
        return imageList.size
    }
}
