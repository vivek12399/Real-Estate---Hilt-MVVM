package com.example.property.model

data class CategoryItem(val title: String, val imageResId: Int)
