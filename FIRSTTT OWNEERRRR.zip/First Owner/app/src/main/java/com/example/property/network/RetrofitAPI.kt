package com.example.property.network

import com.example.property.network.models.AuthModels.LoginRequest
import com.example.property.network.models.AuthModels.LoginResponse
import com.example.property.network.models.AuthModels.UserRegisterRequest
import com.example.property.network.models.AuthModels.UserRegisterResponse
import com.example.property.network.models.AuthModels.builder.BuilderProfileRequest
import com.example.property.network.models.AuthModels.builder.BuilderProfileResponse
import com.example.property.network.models.AuthModels.builder.BuilderRegisterResponse
import com.example.property.network.models.AuthModels.builder.ProeprtyAddResponse
import com.example.property.network.models.AuthModels.builder.TokenRequest
import com.example.property.network.models.AuthModels.builder.TypeResponse
import com.example.property.network.models.AuthModels.builder.request.BuilderProfileUpdate
import com.example.property.network.models.AuthModels.builder.request.PropertyRequest
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.PartMap

interface RetrofitAPI {

    @POST("login")
    suspend fun userLogin(@Body loginRequest: LoginRequest): Response<LoginResponse>


    @POST("register_user")
    suspend fun userRegister(@Body registerRequest: UserRegisterRequest): Response<UserRegisterResponse>


    @Multipart
    @POST("register_builder")
    suspend fun builderProfile(
        @PartMap data: Map<String, @JvmSuppressWildcards RequestBody>,
        @Part logo: MultipartBody.Part,
        @Part profile: MultipartBody.Part
    ): Response<BuilderRegisterResponse>


    @POST("builder/get_profile")
    suspend fun getBuilderProfile(@Body tokenRequest: TokenRequest): Response<BuilderProfileResponse>


    @POST("get/property_type")
    suspend fun getPropertyType(@Body tokenRequest: TokenRequest): Response<TypeResponse>


    @Multipart
    @POST("add/property")
    suspend fun addProperty(
        @PartMap data: Map<String, @JvmSuppressWildcards RequestBody>,
        @Part img1: MultipartBody.Part,
        @Part img2: MultipartBody.Part,
        @Part img3: MultipartBody.Part,
        @Part img4: MultipartBody.Part,
        @Part img5: MultipartBody.Part
    ): Response<ProeprtyAddResponse>


    @Multipart
    @POST("builder/update_profile")
    suspend fun updateBuilderProfile(
        @Body tokenRequest: BuilderProfileUpdate
    ): Response<ProeprtyAddResponse>
}