package com.example.property.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.property.*
import com.example.property.databinding.TrendingPropertyItemlistBinding
import com.example.property.model.TrendingPropertyModel
import com.example.property.ui.PropertyDetailActivity
import com.example.property.ui.PropertyListActivity

class TrendingPropertyAdapter(private var data: ArrayList<TrendingPropertyModel>,private var isFromBuilder:Int) :
    RecyclerView.Adapter<TrendingPropertyAdapter.ViewHolder>() {


    inner class ViewHolder(private val binding: TrendingPropertyItemlistBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: TrendingPropertyModel) {
            binding.trendingPropertyIcon.setImageResource(item.iconResource)
            binding.trendingPropertyTitle.text = "${item.title}"
            binding.trendingPropertyShortDetail.text = "Description: ${item.desc}"
            binding.trendingPropertyCategory.text = "Category: ${item.category}"
            binding.trendingPropertyPrice.text = "Price: ${item.price}"
            if (position == data.size - 1) {
                // Show the ImageView for the last item
                binding.additionalImageView.visibility = View.VISIBLE
            } else {
                // Hide the ImageView for other items
                binding.additionalImageView.visibility = View.GONE
            }
            binding.additionalImageView.setOnClickListener {
                val context = binding.root.context
                val intent = Intent(context, PropertyListActivity::class.java)
                (context as AppCompatActivity).overridePendingTransition(
                    R.anim.catalyst_fade_in,
                    R.anim.catalyst_fade_out
                )
                // You can add extra data to the intent if needed
                // intent.putExtra("key", "value")
                context.startActivity(intent)
            }
        }
        init {
            // Set a click listener on the item view
            binding.root.setOnClickListener {
                val context = it.context
                if (position == data.lastIndex) {
                    // Clicked on the additionalImageView
                    val intent = Intent(context, PropertyListActivity::class.java)
                    (context as AppCompatActivity).overridePendingTransition(
                        R.anim.catalyst_fade_in,
                        R.anim.catalyst_fade_out
                    )
                    // You can add extra data to the intent if needed
                    // intent.putExtra("key", "value")
                    context.startActivity(intent)
                } else {
                    // Clicked on the item, handle the click for a different activity
                    val intent = Intent(context, PropertyDetailActivity::class.java).putExtra("isFromBuilder",isFromBuilder)
                    (context as AppCompatActivity).overridePendingTransition(
                        R.anim.catalyst_fade_in,
                        R.anim.catalyst_fade_out
                    )
                    // You can add extra data to the intent if needed
                    // intent.putExtra("key", "value")
                    context.startActivity(intent)
                }
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TrendingPropertyAdapter.ViewHolder {
        val binding = TrendingPropertyItemlistBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: TrendingPropertyAdapter.ViewHolder, position: Int) {
        holder.bind(data[position])
    }

}
