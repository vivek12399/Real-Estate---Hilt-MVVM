package com.example.property.network.models.AuthModels.builder

data class BuilderProfileResponse(
    val `data`: DataX,
    val message: String,
    val status: Int
)