package com.example.property.utils

object Constants {

    const val BASE_URL = "https://6a80-2409-4041-6d8a-3a0d-a8c5-49a4-d481-c554.ngrok-free.app"
    const val API_KEY = "XXXXXXXXXXXXXXXXXXXXXXX"
    const val TAG = "FIRSTOWNER"
    const val PREFSTOKENFILE = "TOKEN_MANAGER"
    const val USER_TOKEN = "user_token"
    const val ROLE_ID = "role"
    const val FIRST_TIME_USER ="isFirstTime"
}