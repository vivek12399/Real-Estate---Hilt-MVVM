package com.example.property.model

data class PropertyModel(val iconResource: Int,val title: String,val desc: String,val location: String,val price: String)
