package com.example.property.network.models.AuthModels.builder.request

data class BuilderProfileUpdate(
    val token:String,
    val company_name:String,
    val owner_name:String
)