package com.example.property.network.models.AuthModels

data class UserRegisterResponse(
    val data: Data,
    val message: String,
    val status: Int
)