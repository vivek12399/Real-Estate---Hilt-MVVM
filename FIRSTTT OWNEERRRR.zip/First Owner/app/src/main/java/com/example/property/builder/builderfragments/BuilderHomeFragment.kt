package com.example.property.builder.builderfragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.property.MyViewModel
import com.example.property.R
import com.example.property.adapter.TrendingPropertyAdapter
import com.example.property.databinding.FragmentBuilderHomeBinding
import com.example.property.model.TrendingPropertyModel
import com.example.property.network.models.AuthModels.builder.TokenRequest
import com.example.property.utils.Constants
import com.example.property.utils.NetworkResult
import com.example.property.utils.TokenManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


@AndroidEntryPoint
class BuilderHomeFragment : Fragment() {

    private var _binding :FragmentBuilderHomeBinding?=null
    private val viewModel by viewModels<MyViewModel>()
    @Inject
    lateinit var tokenManager: TokenManager
    private val binding
    get()=_binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentBuilderHomeBinding.inflate(layoutInflater)



        val trendingData = ArrayList<TrendingPropertyModel>()
        val itemsToAdd = listOf(
            TrendingPropertyModel(R.drawable.flatpicture, "Flat", "Apartment", "This is beautiful 3BHK flat with balcony and buccati sofa added", "₹ 70,00,000"),
            TrendingPropertyModel(R.drawable.housepicture, "House", "Tenament", "This is beautiful Home with balcony and parking Area , totally 3 floor available here", "₹ 1,000,0000"),
            TrendingPropertyModel(R.drawable.officepictures, "Office", "Commercial", "Office in JASAL COMPLEX", "₹ 50,00,000")
        )
        trendingData.addAll(itemsToAdd)
        val trendingAdapter = TrendingPropertyAdapter(trendingData,1)
        binding.trendingPropertyRView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.trendingPropertyRView.adapter = trendingAdapter

        val upcomingAdapter = TrendingPropertyAdapter(trendingData,1)
        binding.upcomingProjectRView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.upcomingProjectRView.adapter = upcomingAdapter
        val runningProjects = TrendingPropertyAdapter(trendingData,1)
        binding.runningProjectRView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.runningProjectRView.adapter = runningProjects


        var token = tokenManager.getToken()
        if (token!=null){
            viewModel.getBuilderProfile(TokenRequest(token))
        }else{
            Toast.makeText(requireContext(),"Invalid Authentication Please Try Again",Toast.LENGTH_SHORT).show()
        }
        observableProfile()
        return binding.root
    }
    private fun observableProfile() {
        viewModel.getProfileResponseLiveData.observe(requireActivity(),
            Observer { response ->
                binding.loader.visibility = View.GONE
                when(response){
                    is NetworkResult.Success -> {
                        var data = response.data!!.data

                        if (response.data.status==1){
                            binding.apply {
                                companyName.text=data.company_name
                                ownerName.text = data.owner_name
                                cpCount.text = data.completed_projects
                            }
                        }
                    }
                    is NetworkResult.Error -> {
                        Toast.makeText(requireContext(),response.message, Toast.LENGTH_SHORT).show()
                    }
                    is NetworkResult.Loading -> {
                        binding.loader.visibility = View.VISIBLE
                    }
                }
            })
    }
}