package com.example.property.network.models.AuthModels.builder

data class TokenRequest(
    var token:String
)