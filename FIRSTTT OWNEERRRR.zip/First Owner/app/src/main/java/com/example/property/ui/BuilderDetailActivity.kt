package com.example.property.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.property.R
import com.example.property.adapter.TrendingPropertyAdapter
import com.example.property.bottomnavigations.BuilderContactBottomSheetFragment
import com.example.property.databinding.ActivityBuilderDetailBinding
import com.example.property.model.TrendingPropertyModel

class BuilderDetailActivity : AppCompatActivity() {
    private lateinit var binding:ActivityBuilderDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBuilderDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Glide.with(this)
            .asGif()
            .load(R.drawable.backgif)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(binding.back)
        val trendingData = ArrayList<TrendingPropertyModel>()
        val itemsToAdd = listOf(
            TrendingPropertyModel(R.drawable.flatpicture, "Flat", "Apartment", "This is beautiful 3BHK flat with balcony and buccati sofa added", "₹ 70,00,000"),
            TrendingPropertyModel(R.drawable.housepicture, "House", "Tenament", "This is beautiful Home with balcony and parking Area , totally 3 floor available here", "₹ 1,000,0000"),
            TrendingPropertyModel(R.drawable.officepictures, "Office", "Commercial", "Office in JASAL COMPLEX", "₹ 50,00,000")
        )
        trendingData.addAll(itemsToAdd)
        val trendingAdapter = TrendingPropertyAdapter(trendingData,0)
        binding.trendingPropertyRView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.trendingPropertyRView.adapter = trendingAdapter

        val upcomingAdapter = TrendingPropertyAdapter(trendingData,0)
        binding.upcomingProjectRView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.upcomingProjectRView.adapter = upcomingAdapter
        val runningProjects = TrendingPropertyAdapter(trendingData,0)
        binding.runningProjectRView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.runningProjectRView.adapter = runningProjects


        binding.contactUs.setOnClickListener {
            val bottomSheetFragment = BuilderContactBottomSheetFragment()
            bottomSheetFragment.show(supportFragmentManager, bottomSheetFragment.tag)
        }
    }
}