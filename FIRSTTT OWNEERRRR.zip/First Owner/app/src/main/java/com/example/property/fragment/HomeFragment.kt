package com.example.property.fragment

import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.property.R
import com.example.property.adapter.*
import com.example.property.databinding.FragmentHomeBinding
import com.example.property.model.CategoryItem
import com.example.property.model.TopBuilderModel
import com.example.property.model.TrendingPropertyModel

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private lateinit var sliderAdapter: SilderAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var builderAdapter: TopBuilderAdapter
    private lateinit var trendingAdapter: TrendingPropertyAdapter
    private val images = intArrayOf(
        R.drawable.bgimg, R.drawable.appbgimg, R.drawable.appbgimg,
        R.drawable.appbgimg,
        R.drawable.appbgimg,  R.drawable.appbgimg, R.drawable.appbgimg, R.drawable.appbgimg, R.drawable.appbgimg, R.drawable.appbgimg, R.drawable.appbgimg)
    private var currentPage = 0

    private val handler = Handler()
    private val binding get() = _binding!!
    private val update: Runnable = object : Runnable {
        override fun run() {
            if (currentPage == images.size) {
                currentPage = 0
            }
            binding.sliderView.setCurrentItem(currentPage, true)
            currentPage++
            handler.postDelayed(this, 2000) // Slide every 2 seconds
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        Glide.with(this)
            .asGif()
            .load(R.drawable.ap_icon)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(binding.appIcon)
        Glide.with(this)
            .asGif() // Specify that you're loading a GIF
            .load(R.drawable.ap_icon) // Replace with the actual resource ID of your GIF
            .diskCacheStrategy(DiskCacheStrategy.DATA) // Caches the original data of the GIF
            .transition(DrawableTransitionOptions.withCrossFade()) // Cross-fade animation
            .into(binding.includeProgressBar.appIconLoader)
        Glide.with(this)
            .asGif()
            .load(R.drawable.notification)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(binding.notificationIcon)
        //slider code
        sliderAdapter = SilderAdapter(requireContext(), images)
        binding.sliderView.adapter = sliderAdapter
        handler.post(update) // Start auto-sliding



        //
        val items = mutableListOf(
            CategoryItem("Apartment", R.drawable.appartmenticon),
            CategoryItem("Plot", R.drawable.ploticon),
            CategoryItem("Commercial", R.drawable.comicon),
            CategoryItem("Villah", R.drawable.villahicon),
            CategoryItem("Residential", R.drawable.resicon)
        )
        val adapter = CategoryAdapter(items)
        binding.homeCategoryRView.layoutManager = GridLayoutManager(requireContext(), 3)
        binding.homeCategoryRView.adapter = adapter



        //
        val catLblAdapter = CatagoryLabelAdapter(items)
        binding.categotryForTrendingProperty.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.categotryForTrendingProperty.adapter = catLblAdapter
        val newDataItem = CategoryItem("All",R.drawable.appicon)
        catLblAdapter.addDataAtBeginning(newDataItem)


        //trending
        val trendingData = ArrayList<TrendingPropertyModel>()
        val itemsToAdd = listOf(
            TrendingPropertyModel(R.drawable.flatpicture, "Flat", "Apartment", "This is beautiful 3BHK flat with balcony and buccati sofa added", "₹ 70,00,000"),
            TrendingPropertyModel(R.drawable.housepicture, "House", "Tenament", "This is beautiful Home with balcony and parking Area , totally 3 floor available here", "₹ 1,000,0000"),
            TrendingPropertyModel(R.drawable.officepictures, "Office", "Commercial", "Office in JASAL COMPLEX", "₹ 50,00,000")
        )
        trendingData.addAll(itemsToAdd)
        trendingAdapter =TrendingPropertyAdapter(trendingData,0)
        binding.trendingPropertyRView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.trendingPropertyRView.adapter = trendingAdapter

        //builder
        val topBuilder = listOf(
            TopBuilderModel("RK Group", R.drawable.rkbuilder),
            TopBuilderModel("Ladani Group.", R.drawable.builderimage),
            TopBuilderModel("Meet Builders.",R.drawable.meetbuilder)

        )
        recyclerView = binding.TopTrendingBuilderRView
        builderAdapter = TopBuilderAdapter(topBuilder)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = builderAdapter

        binding.includeProgressBar.progressBarLayout.visibility = View.GONE
        return binding.root
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
        handler.removeCallbacks(update)
    }
}