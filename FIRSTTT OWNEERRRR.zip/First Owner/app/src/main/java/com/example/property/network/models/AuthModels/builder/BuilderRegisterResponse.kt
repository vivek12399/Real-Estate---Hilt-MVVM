package com.example.property.network.models.AuthModels.builder

data class BuilderRegisterResponse(
    val `data`: Data,
    val message: String,
    val status: Int
)