package com.example.property.model

data class TopBuilderModel(val title: String, val iconResource: Int)
