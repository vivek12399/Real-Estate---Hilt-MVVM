package com.example.property.model

data class TrendingPropertyModel(val iconResource: Int,val title: String,val category: String,val desc: String, val price:String)