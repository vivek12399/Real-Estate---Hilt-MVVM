package com.example.property.repository

import android.graphics.Bitmap
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.property.network.RetrofitAPI
import com.example.property.network.models.AuthModels.LoginRequest
import com.example.property.network.models.AuthModels.LoginResponse
import com.example.property.network.models.AuthModels.UserRegisterRequest
import com.example.property.network.models.AuthModels.UserRegisterResponse
import com.example.property.network.models.AuthModels.builder.BuilderProfileRequest
import com.example.property.network.models.AuthModels.builder.BuilderProfileResponse
import com.example.property.network.models.AuthModels.builder.BuilderRegisterResponse
import com.example.property.network.models.AuthModels.builder.ProeprtyAddResponse
import com.example.property.network.models.AuthModels.builder.TokenRequest
import com.example.property.network.models.AuthModels.builder.TypeResponse
import com.example.property.network.models.AuthModels.builder.request.BuilderProfileUpdate
import com.example.property.network.models.AuthModels.builder.request.PropertyRequest
import com.example.property.utils.NetworkResult
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import javax.inject.Inject


class UserRepository @Inject constructor(private val retrofitApi:RetrofitAPI) {

    private val _loginResponseLiveData=MutableLiveData<NetworkResult<LoginResponse>>()
    val loginResponseLiveData: LiveData<NetworkResult<LoginResponse>>
    get() = _loginResponseLiveData



    private val _registerResponseLiveData=MutableLiveData<NetworkResult<UserRegisterResponse>>()
    val registerResponseLiveData: LiveData<NetworkResult<UserRegisterResponse>>
        get() = _registerResponseLiveData

    private val _builderProfileLiveData=MutableLiveData<NetworkResult<BuilderRegisterResponse>>()
    val builderProfileResponseLiveData: LiveData<NetworkResult<BuilderRegisterResponse>>
        get() = _builderProfileLiveData

    private val _propertyAddResponse=MutableLiveData<NetworkResult<ProeprtyAddResponse>>()
    val propertyAddResponse: LiveData<NetworkResult<ProeprtyAddResponse>>
        get() = _propertyAddResponse

    private val _builderProfileResponse = MutableLiveData<NetworkResult<BuilderProfileResponse>>()
    val getBuilderProfileResponse:LiveData<NetworkResult<BuilderProfileResponse>>
        get() = _builderProfileResponse

    private val propertyTypeLiveData = MutableLiveData<NetworkResult<TypeResponse>>()
    val propertyTypeResponse:LiveData<NetworkResult<TypeResponse>>
        get() = propertyTypeLiveData
    private val _builderProfileUpdateResponse = MutableLiveData<NetworkResult<ProeprtyAddResponse>>()
    val builderProfileUpdateResponse:LiveData<NetworkResult<ProeprtyAddResponse>>
        get() = _builderProfileUpdateResponse

    suspend fun updateBuilderProfile(tokenReq: BuilderProfileUpdate){
        _builderProfileUpdateResponse.postValue(NetworkResult.Loading())
        val response = retrofitApi.updateBuilderProfile(tokenReq)
        if (response.isSuccessful && response.body()!=null){
            _builderProfileUpdateResponse.value=NetworkResult.Success(response.body()!!)
        }else if (response.errorBody()!=null){
            _builderProfileUpdateResponse.value=NetworkResult.Error(response.errorBody()!!.toString())
        }else{
            _builderProfileUpdateResponse.value=NetworkResult.Error("Error")
        }
    }
    suspend fun getBuilderProfile(tokenReq:TokenRequest){
        _builderProfileResponse.postValue(NetworkResult.Loading())
        val response = retrofitApi.getBuilderProfile(tokenReq)
        if (response.isSuccessful && response.body()!=null){
            _builderProfileResponse.value=NetworkResult.Success(response.body()!!)
        }else if (response.errorBody()!=null){
            _builderProfileResponse.value=NetworkResult.Error(response.errorBody()!!.toString())
        }else{
            _registerResponseLiveData.value=NetworkResult.Error("Error")
        }
    }
    suspend fun getPropertyType(tokenReq:TokenRequest){
        propertyTypeLiveData.postValue(NetworkResult.Loading())
        val response = retrofitApi.getPropertyType(tokenReq)
        if (response.isSuccessful && response.body()!=null){
            propertyTypeLiveData.value=NetworkResult.Success(response.body()!!)
        }else if (response.errorBody()!=null){
            propertyTypeLiveData.value=NetworkResult.Error(response.errorBody()!!.toString())
        }else{
            propertyTypeLiveData.value=NetworkResult.Error("Error")
        }
    }
    suspend fun addProperty(addPropertyRequest: PropertyRequest) {
        _propertyAddResponse.postValue(NetworkResult.Loading())
        val data = mapOf(
            "token" to addPropertyRequest.token.toRequestBody("text/plain".toMediaTypeOrNull()),
            "property_name" to addPropertyRequest.propertyName.toRequestBody("text/plain".toMediaTypeOrNull()),
            "price" to addPropertyRequest.price.toRequestBody("text/plain".toMediaTypeOrNull()),
            "built_in" to addPropertyRequest.buildYear.toRequestBody("text/plain".toMediaTypeOrNull()),
            "description" to addPropertyRequest.description.toRequestBody("text/plain".toMediaTypeOrNull()),
            "facility" to addPropertyRequest.facalities.toRequestBody("text/plain".toMediaTypeOrNull()),
            "current_state" to addPropertyRequest.propertyStatus.toRequestBody("text/plain".toMediaTypeOrNull()),
            "type" to addPropertyRequest.propertyType.toRequestBody("text/plain".toMediaTypeOrNull()),
        )

        val img1 = createImagePart("image1", addPropertyRequest.image1)
        val img2 = createImagePart("image2", addPropertyRequest.image2)
        val img3 = createImagePart("image3", addPropertyRequest.image3)
        val img4 = createImagePart("image4", addPropertyRequest.image4)
        val img5 = createImagePart("image5", addPropertyRequest.image5)
        val response = retrofitApi.addProperty(data, img1,img2, img3, img4, img5)

        if (response.isSuccessful && response.body() != null) {
            _propertyAddResponse.postValue(NetworkResult.Success(response.body()!!))
        } else if (response.errorBody() != null) {
            _propertyAddResponse.postValue(NetworkResult.Error(response.errorBody()!!.string()))
        } else {
            _propertyAddResponse.postValue(NetworkResult.Error("Error"))
        }
    }
    suspend fun builderProfile(builderProfileRequest: BuilderProfileRequest) {
        _builderProfileLiveData.postValue(NetworkResult.Loading())
        val data = mapOf(
            "username" to builderProfileRequest.userName.toRequestBody("text/plain".toMediaTypeOrNull()),
            "company_name" to builderProfileRequest.builderCompanyName.toRequestBody("text/plain".toMediaTypeOrNull()),
            "email" to builderProfileRequest.email.toRequestBody("text/plain".toMediaTypeOrNull()),
            "mobile_no" to builderProfileRequest.mobileNumber.toRequestBody("text/plain".toMediaTypeOrNull()),
            "password" to builderProfileRequest.password.toRequestBody("text/plain".toMediaTypeOrNull()),
            "owner_name" to builderProfileRequest.ownerName.toRequestBody("text/plain".toMediaTypeOrNull()),
            "company_objective" to builderProfileRequest.companyObjective.toRequestBody("text/plain".toMediaTypeOrNull()),
            "city" to builderProfileRequest.companyCity.toRequestBody("text/plain".toMediaTypeOrNull()),
            "achievement" to builderProfileRequest.companyAchievement.toRequestBody("text/plain".toMediaTypeOrNull()),
            "year_since" to builderProfileRequest.companySince.toString().toRequestBody("text/plain".toMediaTypeOrNull()),
            "experiance" to builderProfileRequest.companyExperience.toString().toRequestBody("text/plain".toMediaTypeOrNull())
        )

        val logoPart = createImagePart("logo", builderProfileRequest.logoBitmap)
        val profilePart = createImagePart("profile_pic", builderProfileRequest.profileBitmap)

        val response = retrofitApi.builderProfile(data, logoPart, profilePart)

        if (response.isSuccessful && response.body() != null) {
            _builderProfileLiveData.postValue(NetworkResult.Success(response.body()!!))
        } else if (response.errorBody() != null) {
            _builderProfileLiveData.postValue(NetworkResult.Error(response.errorBody()!!.string()))
        } else {
            _builderProfileLiveData.postValue(NetworkResult.Error("Error"))
        }
    }

    suspend fun userLogin(loginRequest: LoginRequest){
        _loginResponseLiveData.postValue(NetworkResult.Loading())
        val response = retrofitApi.userLogin(loginRequest)

        if (response.isSuccessful && response.body()!=null){
            _loginResponseLiveData.value=NetworkResult.Success(response.body()!!)
        }else if (response.errorBody()!=null){
            _loginResponseLiveData.value=NetworkResult.Error(response.errorBody()!!.toString())
        }else{
            _loginResponseLiveData.value=NetworkResult.Error("Error")
        }
    }
    suspend fun userRegister(userRegister: UserRegisterRequest){
        _registerResponseLiveData.postValue(NetworkResult.Loading())
        val response = retrofitApi.userRegister(userRegister)
        if (response.isSuccessful && response.body()!=null){
            _registerResponseLiveData.value=NetworkResult.Success(response.body()!!)
        }else if (response.errorBody()!=null){
            _registerResponseLiveData.value=NetworkResult.Error(response.errorBody()!!.toString())
        }else{
            _registerResponseLiveData.value=NetworkResult.Error("Error")
        }
    }



    private fun createImagePart(name: String, bitmap: Bitmap?): MultipartBody.Part {
        val stream = ByteArrayOutputStream()
        bitmap?.compress(Bitmap.CompressFormat.PNG, 100, stream)
        val byteArray = stream.toByteArray()
        val requestBody = byteArray.toRequestBody("image/png".toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(name, "$name.png", requestBody)
    }
}