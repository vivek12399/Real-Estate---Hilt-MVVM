package com.example.property.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.property.ui.BuilderDetailActivity
import com.example.property.ui.BuilderListActivity
import com.example.property.R
import com.example.property.databinding.TopBuilderListitemBinding
import com.example.property.model.TopBuilderModel

class TopBuilderAdapter(private var data: List<TopBuilderModel>) :
    RecyclerView.Adapter<TopBuilderAdapter.ViewHolder>() {





    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TopBuilderAdapter.ViewHolder {
        val binding = TopBuilderListitemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TopBuilderAdapter.ViewHolder, position: Int) {
        holder.bind(data[position])

    }

    override fun getItemCount(): Int {
        return data.size
    }
    inner class ViewHolder(private val binding: TopBuilderListitemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: TopBuilderModel) {
            binding.builderListIcon.setImageResource(item.iconResource)
            binding.topBuilderTitle.text = item.title

            if (position == data.lastIndex) {
                // Show the ImageView for the last item
                binding.additionalImageView.visibility = View.VISIBLE
            } else {
                // Hide the ImageView for other items
                binding.additionalImageView.visibility = View.GONE
            }
            binding.additionalImageView.setOnClickListener {
                val context = binding.root.context
                val intent = Intent(context, BuilderListActivity::class.java)
                (context as AppCompatActivity).overridePendingTransition(
                    R.anim.catalyst_fade_in,
                    R.anim.catalyst_fade_out
                )
                // You can add extra data to the intent if needed
                // intent.putExtra("key", "value")


                context.startActivity(intent)
            }


        }
        init {
            // Set a click listener on the item view
            binding.root.setOnClickListener {
                val context = it.context
                if (position == data.lastIndex) {
                    // Clicked on the additionalImageView
                    val intent = Intent(context, BuilderListActivity::class.java)
                    (context as AppCompatActivity).overridePendingTransition(
                        R.anim.catalyst_fade_in,
                        R.anim.catalyst_fade_out
                    )
                    // You can add extra data to the intent if needed
                    // intent.putExtra("key", "value")
                    context.startActivity(intent)
                } else {
                    // Clicked on the item, handle the click for a different activity
                    val intent = Intent(context, BuilderDetailActivity::class.java)
                    (context as AppCompatActivity).overridePendingTransition(
                        R.anim.catalyst_fade_in,
                        R.anim.catalyst_fade_out
                    )
                    // You can add extra data to the intent if needed
                    // intent.putExtra("key", "value")
                    context.startActivity(intent)
                }
            }
        }
    }
}
