package com.example.property.model

data class InquiryModel(var id:Int,var title:String,var desc:String,var date:String,var email:String,var userName:String)