package com.example.property.model

data class ImageItem(val imageResId: Int)
