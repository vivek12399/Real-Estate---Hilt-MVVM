package com.example.property.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.property.ui.PropertyDetailActivity
import com.example.property.databinding.PropertyListitemBinding
import com.example.property.model.PropertyModel

class ProperyAdapter(private var data: ArrayList<PropertyModel>,private var isFromBuilder:Int) :
    RecyclerView.Adapter<ProperyAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ProperyAdapter.ViewHolder {
        val binding = PropertyListitemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProperyAdapter.ViewHolder, position: Int) {
        holder.bind(data[position])
    }

    override fun getItemCount(): Int {
        return data.size
    }
    inner class ViewHolder(private val binding: PropertyListitemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: PropertyModel) {
            binding.propertyListImage.setImageResource(item.iconResource)
            binding.PropertyListTitle.text = "${item.title}"
            binding.PropertyListDetails.text = "Details :  ${item.desc}"
            binding.PropertyPrice.text = "Price : ${item.price}"
            binding.PropertyLocation.text = "Location : ${item.location}"

        }
        init {
            binding.root.setOnClickListener {
                val context = it.context
                    // Clicked on the item, handle the click for a different activity
                    val intent = Intent(context, PropertyDetailActivity::class.java).putExtra("isFromBuilder",isFromBuilder)
                    // You can add extra data to the intent if needed
                    // intent.putExtra("key", "value")
                    context.startActivity(intent)
            }
        }
    }
}