package com.example.property.ui

import android.app.Dialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.property.R
import com.example.property.adapter.*
import com.example.property.bottomnavigations.InquiryFormFragment
import com.example.property.builder.BuilderPropertyAddActivity
import com.example.property.databinding.ActivityPropertyDetailBinding
import com.example.property.databinding.PopupSliderLayoutBinding
import com.example.property.model.ImageItem
import com.example.property.model.TrendingPropertyModel

class PropertyDetailActivity : AppCompatActivity() {
    lateinit var binding:ActivityPropertyDetailBinding
    private lateinit var sliderAdapter: SilderAdapter
    private val images = intArrayOf(
        (R.drawable.homeone),
        (R.drawable.hometwo),
        (R.drawable.homethree),
        (R.drawable.homefour),
        (R.drawable.homefive),
        (R.drawable.homesix),
        (R.drawable.homeseven),
        (R.drawable.homeeight),
        (R.drawable.homenine),
        (R.drawable.hometen),
        (R.drawable.homeeleven),
        (R.drawable.hometwelve))
    private var currentPage = 0
    private var isFromBuilder:Int?=null

    private val handler = Handler()
    private val update: Runnable = object : Runnable {
        override fun run() {
            if (currentPage == images.size) {
                currentPage = 0
            }
            binding.sliderView.setCurrentItem(currentPage, true)
            currentPage++
            handler.postDelayed(this, 2000) // Slide every 2 seconds
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPropertyDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)


        isFromBuilder = intent.getIntExtra("isFromBuilder",0)


        if (isFromBuilder==1){
            binding.inquiryButton.visibility = View.GONE
            binding.categotyTag.visibility = View.GONE
            binding.categoryLayout.visibility = View.GONE
            binding.edit.visibility  = View.VISIBLE
            binding.deleteButton.visibility = View.VISIBLE
        }


        binding.edit.setOnClickListener {
            startActivity(Intent(this,BuilderPropertyAddActivity::class.java))
            overridePendingTransition(
                R.anim.catalyst_fade_in,
                R.anim.catalyst_fade_out
            )
        }
        binding.inquiryButton.setOnClickListener {
            val inquiryFormFragment = InquiryFormFragment()
            inquiryFormFragment.show(supportFragmentManager, inquiryFormFragment.tag)
            overridePendingTransition(
                R.anim.catalyst_fade_in,
                R.anim.catalyst_fade_out
            )
        }


        sliderAdapter = SilderAdapter(this, images)
        binding.sliderView.adapter = sliderAdapter
        handler.post(update) // Start auto-sliding
        Glide.with(this)
            .asGif()
            .load(R.drawable.backgif)
            .diskCacheStrategy(DiskCacheStrategy.DATA)
            .transition(DrawableTransitionOptions.withCrossFade())
            .into(binding.back)
        //trending
        val trendingData = ArrayList<TrendingPropertyModel>()
        val itemsToAdd = listOf(
            TrendingPropertyModel(R.drawable.flatpicture, "Flat", "Apartment", "This is beautiful 3BHK flat with balcony and buccati sofa added", "₹ 70,00,000"),
            TrendingPropertyModel(R.drawable.housepicture, "House", "Tenament", "This is beautiful Home with balcony and parking Area , totally 3 floor available here", "₹ 1,000,0000"),
            TrendingPropertyModel(R.drawable.officepictures, "Office", "Commercial", "Office in JASAL COMPLEX", "₹ 50,00,000")
        )
        trendingData.addAll(itemsToAdd)
        val trendingAdapter = TrendingPropertyAdapter(trendingData,0)
        binding.homeCategoryRView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.homeCategoryRView.adapter = trendingAdapter
        val recyclerView: RecyclerView = binding.imgs
        recyclerView.layoutManager = GridLayoutManager(this,5)




        binding.back.setOnClickListener {
            onBackPressed()
        }
        val images = ArrayList<ImageItem>()
        val imageList = listOf(
            ImageItem(R.drawable.homeone),
            ImageItem(R.drawable.hometwo),
            ImageItem(R.drawable.homethree),
            ImageItem(R.drawable.homefour),
            ImageItem(R.drawable.homefive),
            ImageItem(R.drawable.homesix),
            ImageItem(R.drawable.homeseven),
            ImageItem(R.drawable.homeeight),
            ImageItem(R.drawable.homenine),
            ImageItem(R.drawable.hometen),
            ImageItem(R.drawable.homeeleven),
            ImageItem(R.drawable.hometwelve),

        )
        images.addAll(imageList)
        recyclerView.layoutManager = GridLayoutManager(this,4)
        val adapter = ImageAdapter(imageList) { position ->
            showImageSlider(imageList, position)
        }
        recyclerView.adapter = adapter
    }

    private fun showImageSlider(imageList: List<ImageItem>, initialPosition: Int) {
        val dialogBinding = PopupSliderLayoutBinding.inflate(layoutInflater)
        val imageSlider = dialogBinding.imageSlider

        val dialog = Dialog(this)

        // Set the dialog's content view
        dialog.setContentView(dialogBinding.root)

        // Get the window of the dialog and adjust its attributes
        val window = dialog.window
        val layoutParams = window?.attributes

        // Set the width and height to match the parent
        layoutParams?.width = ViewGroup.LayoutParams.MATCH_PARENT
        layoutParams?.height = ViewGroup.LayoutParams.MATCH_PARENT

        // Apply the adjusted attributes to the window
        window?.attributes = layoutParams

        val adapter = ImageSliderAdapter(imageList)
        imageSlider.adapter = adapter
        imageSlider.setCurrentItem(initialPosition, false)

        dialog.show()

        val closeButton = dialogBinding.closeButton
        closeButton.setOnClickListener {
            dialog.dismiss()
        }
    }

}