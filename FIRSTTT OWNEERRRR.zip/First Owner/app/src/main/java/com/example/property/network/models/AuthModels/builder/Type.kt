package com.example.property.network.models.AuthModels.builder

data class Type(
    val id: Int,
    val name: String
)