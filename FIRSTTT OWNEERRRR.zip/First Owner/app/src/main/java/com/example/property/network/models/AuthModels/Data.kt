package com.example.property.network.models.AuthModels

data class Data(
    val answer: String,
    val created_on: String,
    val email: String,
    val id: String,
    val mobile_no: String,
    val password: String,
    val question: String,
    val question_id: String,
    val role_id: String,
    val token: String,
    val updated_on: String,
    val username: String
)