package com.example.property.network.models.AuthModels.builder

data class ProeprtyAddResponse(
    val message: String,
    val status: Int
)